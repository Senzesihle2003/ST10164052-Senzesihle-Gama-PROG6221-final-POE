﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe
{
    internal class Steps
    {
        private string instructions;

        public string Instructions 
        { 
            get { return instructions; } 
             set { instructions = value; }
        } 
    }
}

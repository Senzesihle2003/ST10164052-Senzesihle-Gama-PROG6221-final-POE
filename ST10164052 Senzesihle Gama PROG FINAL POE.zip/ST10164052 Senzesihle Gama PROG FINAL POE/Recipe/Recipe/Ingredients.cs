﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe
{
    internal class Ingredients
    {
        //Declarations
        private string name;
        private int quantity;
        private string unitMeasurement;
        private Steps[] instructions;
        private string recipeName;
        private int calories;
      
        private string foodGroup;



        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Quantity
        {
            get
            {
                return quantity;
            }
            set { quantity = value; }
        }

        public string UnitMeasurement
        {
            get { return unitMeasurement; }
            set { unitMeasurement = value; }
        }


        public Steps[] Steps
        {
            get { return instructions; }
            set { instructions = value; }
        }

        public string RecipeName
        {
            get { return recipeName; }
            set { recipeName = value; }
        }

        public int Calories
        {
            get { return calories; }
            set { calories = value; }
        }

        
        

        public string FoodGroup
        {
            get { return foodGroup; }
            set { foodGroup = value; }
        }
        public Ingredients(string name, int quantity, string unitMeasurement, Steps[] steps,string recipeName, int calories, string foodGroup)
        {
            this.recipeName = recipeName;
            this.name = name;
            this.quantity = quantity;
            this.unitMeasurement = unitMeasurement;
            this.instructions = steps;
            this.calories = calories;
          
            this.foodGroup = foodGroup;
        }


      //Outputs
        public void Display()
        {
            Console.WriteLine("Recipe name: " + recipeName);
            Console.WriteLine("Ingredient name: " + name);
            Console.WriteLine("Ingredient quantity: " + quantity);
            Console.WriteLine("Ingredient unit of measurement: " + unitMeasurement);
            Console.WriteLine("Ingredient calories: " + calories + "kcals!");
           
            Console.WriteLine("Ingredients food group: " + foodGroup + ".");


            foreach (var steps in instructions)
            {
                Console.WriteLine("Step/Instructions: " + steps.Instructions +"!");
            }

           


        }
      
     
    
    }
}

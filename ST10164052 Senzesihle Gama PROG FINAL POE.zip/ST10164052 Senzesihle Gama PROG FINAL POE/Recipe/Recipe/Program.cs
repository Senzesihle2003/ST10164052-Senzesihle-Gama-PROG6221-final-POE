﻿using Recipe;
using System.Security.Cryptography;
using System.Xml.Linq;

internal class Program
{
    private static void Main(string[] args)
    {
        //Delarations
        double totalCalories;


        //Inputs

        Console.WriteLine("Enter the name of the recipe");
        string recipeName = Console.ReadLine();

        Console.WriteLine("Enter the number of ingredients: ");
        int numIngredients = int.Parse(Console.ReadLine());

        Ingredients[] ingredients = new Ingredients[numIngredients];

        for (int i = 0; i < numIngredients; i++)
        {
            Console.Write("Enter ingredient name: ");
            string name = Console.ReadLine();

            Console.Write("Enter ingredient quantity: ");
            int quantity = int.Parse(Console.ReadLine());

            Console.Write("Enter ingredient unit of measurement: ");
            string unitMeasurement = Console.ReadLine();

            Console.WriteLine("How many calories does the ingredient contain?");
            int calories = int.Parse(Console.ReadLine());

            Console.Write("To which food group does the ingredient belong to?");
            string foodGroup = Console.ReadLine();

            Console.Write("Enter the number of steps: ");
            int num2 = int.Parse(Console.ReadLine());
            Steps[] steps = new Steps[num2];

            for (int j = 0; j < num2; j++)
            {
                steps[j] = new Steps();
                Console.Write("Step " + (j + 1) + " : ");
                string instructions = Console.ReadLine();

                steps[j].Instructions = instructions;
            }
            ingredients[i] = new Ingredients(name, quantity, unitMeasurement, steps, recipeName, calories, foodGroup);
            //Calculations
            totalCalories = calories + calories;
            Console.WriteLine("Total calories: " + totalCalories + "kcals");
            if (totalCalories > 300)
            {
                Console.WriteLine("Total calories of the recipe have exceeded 300kcals");
            }

        }
        //Outputs
        foreach (var Ingredients in ingredients)
        {

            Ingredients.Display();
        }
        //Filtering the list of recipes
        Console.WriteLine("Enter a number option for how you would like to filter the list of recipes: ");
        Console.WriteLine("1.Name of an ingredient ");
        Console.WriteLine("2.Type of food group");
        Console.WriteLine("3.Maximum calories");
        
        
        int choose = int.Parse(Console.ReadLine());
        switch (choose)
        {
            case 1:
                foreach (var Ingredients in ingredients)
                {

                    Ingredients.Display();
                }
                break;
        

            case 2:
                foreach (var FoodGroup in ingredients)
                {

                    FoodGroup.Display();
                }
                break;
        
                

            case 3:
                Console.WriteLine("Input the maximum number of calories: ");
                int maximum = int.Parse(Console.ReadLine());
                if (maximum <= 300)
                {
                    foreach (var Calories in ingredients)
                    {

                        Calories.Display();
                    }

                }
                else
                {
                    Console.WriteLine("Recipe not found");
                }
                break;

            default:
                Console.WriteLine("Invalid option!");

                break;
        }
    }
}
